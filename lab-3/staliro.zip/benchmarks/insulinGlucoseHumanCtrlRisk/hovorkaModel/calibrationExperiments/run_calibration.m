load_system('insulinGlucoseSimHumanCalibration');
%  
% clear 
%  staliro_run_calibration(20,20)
% clear 
%  staliro_run_calibration(15,20)
%  clear
%  staliro_run_calibration(10,20)
%  clear
%  staliro_run_calibration(25,20)
%  clear
% staliro_run_calibration(30,20)
%  clear
% 
%  staliro_run_calibration(20,10)
% 
% clear 
% 
% staliro_run_calibration(15,10)
% clear
% staliro_run_calibration(10,10)
% clear
% staliro_run_calibration(25,10)
% clear
% staliro_run_calibration(30,10)
% clear
% staliro_run_calibration(20,30)
% clear 
% staliro_run_calibration(15,30)
% clear
% staliro_run_calibration(10,30)
% clear
% staliro_run_calibration(25,30)
% clear
% staliro_run_calibration(30,30)
% clear
% staliro_run_calibration(20,40)
clear 
staliro_run_calibration(30,40)
% clear
% staliro_run_calibration(30,50)
% clear
% staliro_run_calibration(30,60)
% clear
% staliro_run_calibration(30,70)
% clear 
% staliro_run_calibration(30,80)
% clear
% staliro_run_calibration(30,90)
