function [transition_okay, options] = transition_check_all_okay(options, old_cost,new_cost)
%transition_check_all_okay All transitions are accepted.

transition_okay = true;

end
