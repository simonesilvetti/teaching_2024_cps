function blkStruct = slblocks
Browser.Library = 'S_TaLiRo';
Browser.Name    = 'S-TaLiRo';
blkStruct.Browser = Browser;


