This folder contains examples of what you can do with S-Taliro beyond the main 
research threads of falsification and parameter mining.
