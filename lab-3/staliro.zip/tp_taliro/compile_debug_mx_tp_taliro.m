mex -g -v -compatibleArrayDims mx_tp_taliro.c cache.c distances.c lex.c DP.c parse.c rewrt.c
