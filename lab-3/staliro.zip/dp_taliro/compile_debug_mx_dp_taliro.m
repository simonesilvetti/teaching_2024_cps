mex -g -v -compatibleArrayDims mx_dp_taliro.c cache.c distances.c lex.c DynamicProgramming.c parse.c rewrt.c
