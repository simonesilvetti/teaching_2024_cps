% Not equal overloaded for hydis class

% (C) 2011 by Georgios Fainekos (fainekos@asu.edu)
% Last update: 2011.06.04

function out = eq(inp1,inp2)
out = ~eq(inp1,inp2);
end
