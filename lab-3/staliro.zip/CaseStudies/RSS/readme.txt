
Requirements:
S-Taliro (minimally dp_taliro)
CommonRoad 2017 (included)

Main file:
RSS_Demo_S_Taliro_without_intersection.m
or, if you have dp_taliro updated version that supports 'Rns', then you can use the below file
RSS_Demo_S_Taliro_without_intersection_updated.m

NOTE:
The complete project abd case studies are stored here:
https://cpslab.assembla.com/spaces/s-taliro_public/git/source/master/RSS