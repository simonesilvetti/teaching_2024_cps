% FIELDNAMES for hydis class
% It returns empty. No direct access to fields is allowed.

% (C) 2011 by Georgios Fainekos (fainekos@asu.edu)
% Last update: 2011.06.04

function out = fieldnames(varargin)
out = [];
