The modifications to staliro is to return whole trajectory inside history.
The modifications are done wrt the revision on February 12 (please double check if it makes sense)