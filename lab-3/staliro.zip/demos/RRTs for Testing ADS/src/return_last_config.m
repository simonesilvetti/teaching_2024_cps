function [config_id] = return_last_config(options, configurations, agent, final_configs)
%return_last_config Simply returns the last config as the best config.
    
    config_id = length(configurations);
end

