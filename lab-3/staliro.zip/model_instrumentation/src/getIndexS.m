function i = getIndexS(block, info)

i = info.startOfS + block - 1;
end

